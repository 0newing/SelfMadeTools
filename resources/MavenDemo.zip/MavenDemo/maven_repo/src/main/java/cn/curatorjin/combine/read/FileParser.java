/*
 *
 * 文件名: FileParser.java
 * 描述: 一句话描述
 * 创建人: 0newing
 * 时间: 2019/1/21  23:15
 *
 */
package cn.curatorjin.combine.read;

import cn.curatorjin.combine.beans.SubType;
import cn.curatorjin.combine.beans.VulType;
import cn.curatorjin.utils.CloseUtil;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * 文件解析器
 *
 * @author : 0newing
 * @version : 2.0
 */
public class FileParser
{
    private FileParser(){}

    /**
     * 获取所有小类
     *
     * @return 以TYPE_ID为Key，对应小类列表为Value的Map
     */
    private static Map<String, List<SubType>> getAllSubTypes(File subTypeFile)
    {
        Map<String, List<SubType>> resultMap = new HashMap<>();
        boolean skip = true;
        BufferedReader br = null;
        try
        {
            br = new BufferedReader(new FileReader(subTypeFile));
            String line;
            while ((line = br.readLine()) != null)
            {
                if (skip)
                {
                    skip = !skip;
                    continue;
                }
                String[] subTypeInfo = line.split("\t");
                if (subTypeInfo.length == 3)
                {
                    String typeId = subTypeInfo[0];
                    List<SubType> list = resultMap.get(typeId);
                    if (null == list)
                    {
                        list = new ArrayList<>();
                    }
                    list.add(new SubType(subTypeInfo[1], subTypeInfo[2]));
                    resultMap.put(typeId, list);
                }
                skip = !skip;
            }
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        finally
        {
            CloseUtil.closeStream(br);
        }

        return resultMap;
    }

    /**
     * 获取所有大类
     *
     * @return 所有大类集合
     */
    public static List<VulType> getAllVulTypes(File vulTypeFile,File subTypeFile)
    {
        List<VulType> resultList = new ArrayList<>();
        BufferedReader br = null;
        boolean skip = true;
        try
        {
            Map<String, List<SubType>> subTypes = getAllSubTypes(subTypeFile);
            br = new BufferedReader(new FileReader(vulTypeFile));
            String line;
            while ((line = br.readLine()) != null)
            {
                if (skip)
                {
                    skip = !skip;
                    continue;
                }
                String[] typeInfo = line.split("\t");
                if (typeInfo.length == 4)
                {
                    VulType vulType = new VulType(typeInfo[0], typeInfo[1], typeInfo[2],
                        typeInfo[3]);
                    vulType.setSubTypes(subTypes.get(typeInfo[0]));
                    resultList.add(vulType);
                }
                skip = !skip;
            }
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        finally
        {
            CloseUtil.closeStream(br);
        }
        return resultList;
    }

    /**
     * 获取翻译内容
     *
     * @return 翻译内容
     */
    public static Map<String, String> getTransMap(File transFile)
    {
        Map<String, String> trans = new HashMap<>();
        BufferedReader br = null;
        try
        {
            br = new BufferedReader(new FileReader(transFile));
            String line;
            while ((line = br.readLine()) != null)
            {
                String[] transInfo = line.split("\t");
                if (transInfo.length == 4)
                {
                    trans.put(transInfo[2], transInfo[3]);
                }
            }
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        finally
        {
            CloseUtil.closeStream(br);
        }
        return trans;
    }
}
