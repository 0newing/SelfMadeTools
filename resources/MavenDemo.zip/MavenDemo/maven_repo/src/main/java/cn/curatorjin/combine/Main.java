/*
 *
 * 文件名: Main.java
 * 描述: 一句话描述
 * 创建人: 0newing
 * 时间: 2019/1/21  21:55
 *
 */
package cn.curatorjin.combine;

import cn.curatorjin.combine.beans.VulType;
import cn.curatorjin.combine.read.FileParser;
import cn.curatorjin.combine.write.XlsxWriter;
import org.apache.commons.cli.BasicParser;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;


/**
 * 启动器
 *
 * @author : 0newing
 * @version : 2.0
 */
public class Main
{
    /**
     * Main
     *
     * @param args 参数
     */
    public static void main(String[] args)
    {
        File typeFile;
        File subFile;
        File transFile;
        CommandLineParser parser = new BasicParser();
        Options options = new Options();
        options.addOption("t", "typeFile", true, "大类的文件");
        options.addOption("s", "subTypeFile", true, "小类的文件");
        options.addOption("m", "transMap", true, "翻译文件");
        CommandLine commandLine;
        try
        {
            commandLine = parser.parse(options, args);
            if (commandLine.hasOption("t"))
            {
                typeFile = new File(commandLine.getOptionValue("t"));
            }
            else
            {
                typeFile = new File("type.txt");
            }
            if (commandLine.hasOption("s"))
            {
                subFile = new File(commandLine.getOptionValue("s"));
            }
            else
            {
                subFile = new File("subtype.txt");
            }
            if (commandLine.hasOption("m"))
            {
                transFile = new File(commandLine.getOptionValue("m"));
            }
            else
            {
                transFile = new File("trans.txt");
            }

            if (typeFile.exists() && subFile.exists() && transFile.exists())
            {
                List<VulType> vulTypes = FileParser.getAllVulTypes(typeFile, subFile);
                Map<String, String> transMap = FileParser.getTransMap(transFile);
                XlsxWriter xlsxWriter = new XlsxWriter();

                xlsxWriter.combineType(vulTypes,transMap);
            }
            else
            {
                System.out.println("文件不存在");
            }
        }
        catch (ParseException e)
        {
            e.printStackTrace();
        }

    }
}
