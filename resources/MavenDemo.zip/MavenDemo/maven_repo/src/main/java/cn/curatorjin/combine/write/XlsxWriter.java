/*
 *
 * 文件名: XlsxWriter.java
 * 描述: 一句话描述
 * 创建人: 0newing
 * 时间: 2019/1/21  23:14
 *
 */
package cn.curatorjin.combine.write;

import cn.curatorjin.combine.beans.SubType;
import cn.curatorjin.combine.beans.VulType;
import cn.curatorjin.utils.CloseUtil;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.List;
import java.util.Map;


/**
 * 表格书写者
 *
 * @author : 0newing
 * @version : 2.0
 */
public class XlsxWriter
{
    private String[] headContent = {"TYPE_ID", "TYPE_NAME", "VALUE", "VALUE", "subTYPE_ID",
        "VALUE"};

    public boolean combineType(List<VulType> vulTypes, Map<String, String> tranDict)
    {
        BufferedOutputStream bufferedOutputStream = null;
        Translator translator = new Translator(tranDict);
        boolean result = false;
        Workbook wb = null;
        try
        {
            bufferedOutputStream = new BufferedOutputStream(
                new FileOutputStream(new File("result.xlsx")));
            wb = new XSSFWorkbook();
            Sheet sheet = wb.createSheet();
            Row freeRow = sheet.createRow(0);
            Cell freeCell;
            for (int i = 0; i < headContent.length; i++)
            {
                freeCell = freeRow.createCell(i);
                freeCell.setCellValue(headContent[i]);
            }
            int r = 1;
            for (VulType vulType : vulTypes)
            {

                //大类信息
                freeRow = getRow(sheet, r);
                freeCell = getCell(freeRow, 0);
                freeCell.setCellValue(vulType.getId());
                freeCell = getCell(freeRow, 1);
                freeCell.setCellValue(translator.getString(true, vulType.getName()));
                freeCell = getCell(freeRow, 2);
                freeCell.setCellValue(translator.getString(true, vulType.getDesc()));
                freeCell = getCell(freeRow, 3);
                freeCell.setCellValue(translator.getString(true, vulType.getValue()));

                freeRow = getRow(sheet,r + vulType.getSubTypes().size());
                freeCell = getCell(freeRow,1);
                freeCell.setCellValue(translator.getString(false, vulType.getName()));
                freeCell = getCell(freeRow, 2);
                freeCell.setCellValue(translator.getString(false, vulType.getDesc()));
                freeCell = getCell(freeRow, 3);
                freeCell.setCellValue(translator.getString(false, vulType.getValue()));
                //写小类信息
                List<SubType> subTypes = vulType.getSubTypes();
                for (SubType subType : subTypes)
                {
                    freeRow = getRow(sheet, r);
                    freeCell = getCell(freeRow, 4);
                    freeCell.setCellValue(translator.getString(true, subType.getName()));

                    freeCell = getCell(freeRow, 5);
                    freeCell.setCellValue(translator.getString(true, subType.getDesc()));
                    r++;
                    freeRow = getRow(sheet, r);
                    freeCell = getCell(freeRow, 4);
                    freeCell.setCellValue(translator.getString(false, subType.getName()));

                    freeCell = getCell(freeRow, 5);
                    freeCell.setCellValue(translator.getString(false, subType.getDesc()));
                    r++;
                }

            }

            wb.write(bufferedOutputStream);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
            CloseUtil.closeStream(wb);
            CloseUtil.closeStream(bufferedOutputStream);
        }
        return result;
    }

    private Row getRow(Sheet sheet, int i)
    {
        Row row = sheet.getRow(i);
        return row == null ? sheet.createRow(i) : row;
    }

    private Cell getCell(Row row, int i)
    {
        Cell cell = row.getCell(i);
        return cell == null ? row.createCell(i) : cell;
    }

    class Translator
    {
        private Map<String, String> dict;

        Translator(Map<String, String> dict)
        {
            this.dict = dict;
        }

        protected String getString(boolean lang, String s)
        {
            if (lang)
            {
                return s;
            }
            else
            {
                return dict.get(s);
            }
        }
    }
}
