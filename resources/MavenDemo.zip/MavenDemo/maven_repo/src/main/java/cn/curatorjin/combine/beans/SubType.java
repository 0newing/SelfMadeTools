/*
 *
 * 文件名: SubType.java
 * 描述: 一句话描述
 * 创建人: 0newing
 * 时间: 2019/1/21  21:42
 *
 */
package cn.curatorjin.combine.beans;

/**
 * Class/Interface/Enum description
 *
 * @author : 0newing
 * @version : 2.0
 */
public class SubType
{
    /**
     * 小类ID
     */
    private String id;

    /**
     * 小类名
     */
    private String name;

    /**
     * 小类描述
     */
    private String desc;

    public SubType(String name, String desc)
    {
        this.name = name;
        this.desc = desc;
    }

    public String getId()
    {
        return id;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getDesc()
    {
        return desc;
    }

    public void setDesc(String desc)
    {
        this.desc = desc;
    }
}
