/*
 *
 * 文件名: VulType.java
 * 描述: 一句话描述
 * 创建人: 0newing
 * 时间: 2019/1/21  21:39
 *
 */
package cn.curatorjin.combine.beans;

import java.util.List;


/**
 * 大类
 *
 * @author : 0newing
 * @version : 2.0
 */
public class VulType
{
    /**
     * 大类ID
     */
    private String id;

    /**
     * 大类名
     */
    private String name;

    /**
     * 大类描述
     */
    private String desc;

    /**
     * 大类的值(忘了反正)
     */
    private String value;

    /**
     * 对应的小类列表
     */
    private List<SubType> subTypes;

    public VulType(String id, String name, String desc, String value)
    {
        this.id = id;
        this.name = name;
        this.desc = desc;
        this.value = value;
    }

    public String getId()
    {
        return id;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getDesc()
    {
        return desc;
    }

    public void setDesc(String desc)
    {
        this.desc = desc;
    }

    public String getValue()
    {
        return value;
    }

    public void setValue(String value)
    {
        this.value = value;
    }

    public List<SubType> getSubTypes()
    {
        return subTypes;
    }

    public void setSubTypes(List<SubType> subTypes)
    {
        this.subTypes = subTypes;
    }

    @Override
    public String toString()
    {
        return "VulType{" +
               "id='" + id + '\'' +
               ", name='" + name + '\'' +
               ", desc='" + desc + '\'' +
               ", value='" + value + '\'' +
               ", subTypes=" + subTypes +
               '}';
    }
}
