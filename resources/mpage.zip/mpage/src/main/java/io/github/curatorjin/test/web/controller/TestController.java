package io.github.curatorjin.test.web.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestController {

    @RequestMapping(value = "/hello", method = RequestMethod.GET)
    public String sayHello(String serverIp, int deviceType) {
        System.out.println("ServerIp:" + serverIp);
        System.out.println("deviceType:" + deviceType);
        return "ServerIp:" + serverIp + "  DeviceType:" + deviceType;
    }

    @RequestMapping(value = "/get-method", method = RequestMethod.POST)
    public String testGet() {
        return "Hello world";
    }

    @RequestMapping(value = "/post-method", method = RequestMethod.POST)
    public String testPost() {
        return "Hello world";
    }
}
