$(function () {
    $(".nav-btn").click(function () {
        $(".nav-btn").removeClass("active");
        console.log("." + $(this).attr("id") + "Part");
        $(".displayPart").hide();
        $("." + $(this).attr("id") + "Part").show()
        $(this).addClass("active");
    });

    $("#acquireTask").click(function () {
        $.get("/hello?serverIp=" + $("#serverIp").val() + "&deviceType=" + $("#deviceType").val(), function (data, status) {
            $("#dynamicTasksShow").html(data);
            console.log(status);
        });
    });

    $("#reportDevices").click(function () {

    });

    $("#reportVirus").click(function () {

    });

    $("#reportDynamic").click(function () {

    });

    $("#addTask").click(function () {

    });
});